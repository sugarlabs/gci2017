# sugarlabss
hello  sugarlabs! I am ege. ı am from Kadıköy Anadolu Lisesi. I am planning to be a computer enginner in the future. here is the link: https://github.com/EGESERBES/sugarlabss/edit/master/README.md

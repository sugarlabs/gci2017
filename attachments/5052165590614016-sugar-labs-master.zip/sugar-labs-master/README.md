# sugar-labs
Hellos Sugar Labs! I am from Turkey. My name is EGE. I am a student in Kadıköy Anadolu Lisesi. 

# helloworld-omair
Node.js Hello World program

Hi guys, specially Sugar Labs!
This is a simple Node.js program

To run, type the following in terminal:
npm run build

Note:- This is also published to npm.


Thanks!

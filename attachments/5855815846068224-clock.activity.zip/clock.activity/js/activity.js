define(["sugar-web/activity/activity"], function (activity) {

	// Manipulate the DOM only when it is ready.
	require(['domReady!'], function (doc) {

		// Initialize the activity.
		activity.setup();
		var canvas = document.getElementById('canvas');





		var t = window.setInterval(updateTime, 500);
		function updateTime() {
			var canvas = document.getElementById('canvas');
			var now = new Date();
			var hours = now.getUTCHours();
			var mins = now.getUTCMinutes();
			var secs = now.getUTCSeconds();

			if (mins < 10) {
				mins = 0 + mins.toString();

			}

			if (secs < 10) {

				secs = 0 + secs.toString()

			}

			var perc = ((hours*60) + mins) / 1440;

			canvas.innerHTML = '<p class="time">' + (hours - now.getTimezoneOffset() / 60) + ':' + mins +':' + secs + '</p>' +
													'<div id="myProgress">'+
														'<div id="myBar"></div>'+
													'</div>'+
													'<p id="capt">About ' + Math.round(perc) +'% of the day are already gone!</p>'

		  move(perc);

	}

	function move(perc) {
	    var elem = document.getElementById("myBar");
			elem.style.width = perc + '%';

 }


	});

});

# sugarlabs

Hello Sugar Labs,

Yasha89c here, I am from Kulachi Hansraj Model School in New Delhi.
I like doing coding, especially in robotics, also i have achieved black belt and international gold medal in taekwondo.
I have participated robotics competitions like World Robotics Olympiad (WRO) and First Tech Challenge (FTC).
For first time I've participated in codein with google. 

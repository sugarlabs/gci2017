# Turtle Listens

A *Turtle Blocks* plugin with speech recognition blocks.

Speech recognition capabilities are accessed through the the *Sugar Listens* API.

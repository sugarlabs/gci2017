# browse-activity
An activity to browse the internet; WebKit2 on GTK+ on Sugar Toolkit.
This is important to read.

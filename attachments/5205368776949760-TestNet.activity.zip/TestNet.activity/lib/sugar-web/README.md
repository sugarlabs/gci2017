Sugar Web
=========

These are the tools that a developer can use to make a web
activity.

For details see: http://developer.sugarlabs.org/

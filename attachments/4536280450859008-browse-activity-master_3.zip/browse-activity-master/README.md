+# browse-activity 
+Browser is a computer program with a graphical user interface for displaying HTML files, used to navigate the World Wide Web.
+A browse-activity is to browse the internet WebKit2 on GTK+ on Sugar Toolkit.
+This is a python generated activity to browse the internet using webkit on gtk+ on sugar toolkit


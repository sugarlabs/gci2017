# sugarlabs


Hello sugarlabs,


Rahul Raj here, I am a participant of google code in. I am new to coding and it's fun.
Hope I am doing the task correctly. I like phython and C#.

Thank you
